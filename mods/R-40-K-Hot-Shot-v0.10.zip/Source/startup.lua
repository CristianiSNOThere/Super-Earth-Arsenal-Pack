return function(make_api, patch)
    if rawget(_G, 'R40KMagazineTuneV08') then return end
    local state = {
        version = '0.8', active = false,
        status = 'Waiting for first game update', scanned = 0, candidates = 0, diagnostics = {},
    }
    _G.R40KMagazineTuneV08 = state
    local previous = update
    local callback

    local function log()
        pcall(function()
            local logger = rawget(_G, 'CowboyBingusModLoader')
            local file = logger and logger.open_log and logger.open_log('R40KMagazineTune.log')
            if file then
                file:write('R40KMagazineTune v0.8\nstatus=' .. state.status ..
                    '\nscanned_bytes=' .. state.scanned .. '\ncandidates=' .. state.candidates ..
                    '\n' .. table.concat(state.diagnostics, '\n') .. '\n')
                file:close()
            end
        end)
    end

    local deadline, logged_mb = 0, -1
    local worker = coroutine.create(function()
        for _, name in ipairs({
            'R40KHeatSinkModV3', 'R40KHeatSinkModV4', 'R40KHeatSinkModV5',
            'R40KHeatSinkModV7',
        }) do
            assert(not rawget(_G, name),
                'Disable every older Hot-Shot prototype before enabling v0.8. No v0.8 changes applied.')
        end

        local api = make_api()
        api.note = function(message)
            if #state.diagnostics >= 16 then table.remove(state.diagnostics, 1) end
            state.diagnostics[#state.diagnostics + 1] = 'validation=' .. message
        end
        api.checkpoint = function(stage, force)
            state.status = stage
            if force or os.clock() >= deadline then coroutine.yield() end
        end
        api.progress = function(scanned, total, candidates)
            state.scanned, state.candidates = scanned, candidates
            local mb = math.floor(scanned / 16777216)
            if mb ~= logged_mb then logged_mb = mb; log() end
        end

        local exe, game = api.module(nil), api.module('game.dll')
        assert(exe ~= nil and game ~= nil, 'Game modules unavailable')
        state.status = 'Waiting for generated weapon data to load'
        log()
        local load_until = api.now() + 15000
        repeat coroutine.yield() until api.now() >= load_until

        local peer_deadline = api.now() + 90000
        local peers = {'FlagDamagePrototypeV1', 'SaiFocusModV1', 'AR11ArbitratorModV1'}
        while true do
            local pending = {}
            for _, name in ipairs(peers) do
                local peer = rawget(_G, name)
                if peer and not peer.active then pending[#pending + 1] = name end
            end
            if #pending == 0 then break end
            if api.now() >= peer_deadline then
                error('An enabled Flag, SAI, or AR-11 mod did not finish initialization. No R/40-K changes applied.')
            end
            state.status = 'Waiting for enabled Flag, SAI, and AR-11 mods to finish'
            log()
            coroutine.yield()
        end

        for attempt = 1, 8 do
            local applied, reason = patch.apply(api, game)
            if applied then return reason end
            local not_ready = reason == 'not-ready'
            local stale = reason:find('changed before commit', 1, true) ~= nil
                or reason:find('target changed before commit', 1, true) ~= nil
            local restored_conflict = reason:find('full-table verification failed', 1, true) ~= nil
                and reason:find('restored=true', 1, true) ~= nil
            if (not not_ready and not stale and not restored_conflict) or attempt == 8 then error(reason) end
            state.status = (stale or restored_conflict)
                and 'Shared table changed during setup; retrying safely'
                or 'R/40-K data not ready; retrying after loading'
            log()
            local until_time = api.now() + ((stale or restored_conflict) and 3000 or 10000)
            repeat coroutine.yield() until api.now() >= until_time
        end
    end)

    local function init()
        if coroutine.status(worker) == 'dead' then return end
        deadline = os.clock() + 0.004
        local ok, message = coroutine.resume(worker)
        if not ok or coroutine.status(worker) == 'dead' then
            state.active, state.status = ok, tostring(message)
            print('[R40KMagazineTune] ' .. state.status)
            log()
            if update == callback then update = previous or function() end end
        end
    end

    local function finish(...) init(); return ... end
    callback = function(...)
        if previous then return finish(previous(...)) end
        init()
    end
    update = callback
    log()
end
