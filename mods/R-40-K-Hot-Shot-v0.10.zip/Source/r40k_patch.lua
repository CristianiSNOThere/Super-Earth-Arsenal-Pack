local patch = {}

local GAME_BUILD_EXE = 'F5FEE03DCFDB2E553A4752C283590950AC13316B376D8196AA556FF0400D5F06'
local GAME_BUILD_DLL = '2E2C3B7C2500646DADD5F2B4C6E0504DBB7E7896139F64CDDC0D1813C718F51E'
local R40K_LO, R40K_HI = 0xd26ba391, 0x1abbff60

local TABLES = {
    weapon = {
        label = 'R/40-K weapon data',
        header = 'b1dbe4884c444c4401000000b1dbe488000f07000100000000000000',
        wrapper = 0x88e4dbb1, group_size = 462592,
        map_count = 730, data_offset = 11680, record_count = 366, stride = 1232,
        used_count = 365, target_index = 302, resource_lo = R40K_LO, resource_hi = R40K_HI,
        file_offset = 26151656, ergonomics_offset = 356,
    },
    magazine = {
        label = 'R/40-K magazine data',
        header = 'a3888dfb4c444c4401000000a3888dfb20cb00000100000000000000',
        wrapper = 0xfb8d88a3, group_size = 52000,
        map_count = 540, data_offset = 8640, record_count = 271, stride = 160,
        used_count = 270, target_index = 225, resource_lo = R40K_LO, resource_hi = R40K_HI,
        file_offset = 528664, capacity_offset = 136, starting_offset = 140,
        refill_offset = 144, maximum_offset = 148,
    },
}

local function unhex(value)
    return (value:gsub('..', function(pair) return string.char(tonumber(pair, 16)) end))
end

local function u32(value, offset)
    if not value or offset < 0 or offset + 4 > #value then return nil end
    local a, b, c, d = value:byte(offset + 1, offset + 4)
    return a + b * 256 + c * 65536 + d * 16777216
end

local function pack32(value)
    return string.char(value % 256, math.floor(value / 256) % 256,
        math.floor(value / 65536) % 256, math.floor(value / 16777216) % 256)
end

local function replace(value, offset, replacement)
    return value:sub(1, offset) .. replacement .. value:sub(offset + #replacement + 1)
end

local function same_key(entry, lo, hi)
    return entry.lo == lo and entry.hi == hi
end

local function bucket(lo, hi, count)
    return ((hi % count) * (4294967296 % count) + (lo % count)) % count
end

local function read_group(api, address, config)
    local header = unhex(config.header)
    local size = 28 + config.group_size
    if config.data_offset ~= config.map_count * 16
        or config.group_size ~= config.data_offset + config.record_count * config.stride then
        return nil, 'component-table layout constants are inconsistent'
    end
    if not api.data_access(address, size) then return nil, 'component-table data permissions unsupported' end
    local source = api.read(address, size)
    if not source or #source ~= size then return nil, 'component-table read failed' end
    if source:sub(1, 28) ~= header or u32(source, 0) ~= config.wrapper
        or source:sub(5, 8) ~= 'LDLD' or u32(source, 8) ~= 1
        or u32(source, 12) ~= config.wrapper or u32(source, 16) ~= config.group_size
        or u32(source, 20) ~= 1 or u32(source, 24) ~= 0 then
        return nil, 'component-table header mismatch'
    end
    return {address = address, size = size, source = source, config = config, changes = {},
        writer = api.private_write_blob}
end

local function parse_map(group)
    local config, source = group.config, group.source
    local entries, seen_key, seen_index, count = {}, {}, {}, 0
    for slot = 0, config.map_count - 1 do
        local offset = 28 + slot * 16
        local lo, hi = u32(source, offset), u32(source, offset + 4)
        local index, padding = u32(source, offset + 8), u32(source, offset + 12)
        if lo == 0 and hi == 0 then
            if index ~= 0 or padding ~= 0 then return nil, 'empty component-map slot is malformed' end
            entries[slot] = {lo = 0, hi = 0, index = 0, padding = 0}
        else
            if padding ~= 0 or index >= config.record_count then
                return nil, 'component-map entry has an invalid index or padding'
            end
            local key = string.format('%08x%08x', hi, lo)
            if seen_key[key] or seen_index[index] then
                return nil, 'component map contains duplicate keys or records'
            end
            seen_key[key], seen_index[index] = true, true
            entries[slot] = {lo = lo, hi = hi, index = index, padding = padding}
            count = count + 1
        end
    end
    if count ~= config.used_count then return nil, 'component-map occupancy changed' end
    return entries, count
end

local function validate_probe_chain(entries, capacity)
    for slot = 0, capacity - 1 do
        local entry = entries[slot]
        if entry.lo ~= 0 or entry.hi ~= 0 then
            local start = bucket(entry.lo, entry.hi, capacity)
            local found = false
            for step = 0, capacity - 1 do
                local probe = (start + step) % capacity
                local current = entries[probe]
                if current.lo == 0 and current.hi == 0 then break end
                if same_key(current, entry.lo, entry.hi) then
                    found = probe == slot
                    break
                end
            end
            if not found then return false end
        end
    end
    return true
end

local function target_index(entries, config)
    local found, index = 0, nil
    for slot = 0, config.map_count - 1 do
        local entry = entries[slot]
        if same_key(entry, config.resource_lo, config.resource_hi) then
            found, index = found + 1, entry.index
        end
    end
    if found ~= 1 or index ~= config.target_index then return nil, 'R/40-K resource mapping mismatch' end
    local start = bucket(config.resource_lo, config.resource_hi, config.map_count)
    for step = 0, config.map_count - 1 do
        local slot = (start + step) % config.map_count
        local entry = entries[slot]
        if entry.lo == 0 and entry.hi == 0 then break end
        if same_key(entry, config.resource_lo, config.resource_hi) then return index end
    end
    return nil, 'R/40-K map probe lookup failed'
end

local function record_offset(config, index)
    return 28 + config.data_offset + index * config.stride
end

local function make_plan(api, address, config)
    local group, reason = read_group(api, address, config)
    if not group then return nil, reason end
    local entries, count = parse_map(group)
    if not entries then return nil, count end
    if not validate_probe_chain(entries, config.map_count) then return nil, 'component-map probe structure changed' end
    local index, index_reason = target_index(entries, config)
    if not index then return nil, index_reason end
    local row = record_offset(config, index)
    local function change(offset, before, after, label)
        local field = row + offset
        if group.source:sub(field + 1, field + #before) ~= before then
            return nil, label .. ' differs from the supported stock value'
        end
        return {offset = field, before = before, after = after}
    end

    if config == TABLES.weapon then
        local edit, edit_reason = change(config.ergonomics_offset,
            unhex('0000f041'), unhex('00003442'), 'R/40-K ergonomics 30')
        if not edit then return nil, edit_reason end
        group.changes = {edit}
    else
        if u32(group.source, row) ~= 0 then return nil, 'R/40-K magazine row header changed' end
        local values = {
            {config.capacity_offset, 12, 20, 'magazine capacity 12'},
            {config.starting_offset, 5, 5, 'starting magazines 5'},
            {config.refill_offset, 7, 5, 'refill magazines 7'},
            {config.maximum_offset, 7, 5, 'maximum magazines 7'},
        }
        group.changes = {}
        for _, item in ipairs(values) do
            local edit, edit_reason = change(item[1], pack32(item[2]), pack32(item[3]), item[4])
            if not edit then return nil, edit_reason end
            if edit.before ~= edit.after then group.changes[#group.changes + 1] = edit end
        end
    end
    if api.note then
        api.note(config.label .. ' candidate=' .. string.format('%.0f', api.identity(address)) ..
            ': validated target mapping and stock fields')
    end
    return group
end

local function locate(api, module, config)
    local header, result, seen = unhex(config.header), {}, {}
    local function add(address)
        local key = api.identity(address)
        if not seen[key] then seen[key] = true; result[#result + 1] = address end
    end
    for _, address in ipairs(api.candidates(module, nil, 0, header:sub(1, 16))) do add(address) end
    local found = api.scan_private_many({{signature = header, row_offset = 0, key = 1}}, true)[1]
    for _, address in ipairs(found or {}) do add(address) end
    return result
end

local function expected_after(group)
    local result = group.source
    for _, edit in ipairs(group.changes) do result = replace(result, edit.offset, edit.after) end
    return result
end

local function commit(api, groups)
    local expected = {}
    for index, group in ipairs(groups) do
        assert(api.read(group.address, group.size) == group.source,
            group.config.label .. ' changed before commit')
        expected[index] = expected_after(group)
        for _, edit in ipairs(group.changes) do
            assert(api.read(group.address + edit.offset, #edit.before) == edit.before,
                group.config.label .. ' target changed before commit')
        end
    end
    local attempted = {}
    local ok, reason = pcall(function()
        for _, group in ipairs(groups) do
            for _, edit in ipairs(group.changes) do
                attempted[#attempted + 1] = {group = group, edit = edit}
                assert(group.writer(group.address + edit.offset, edit.after),
                    group.config.label .. ' write was incomplete')
            end
        end
        for index, group in ipairs(groups) do
            assert(api.read(group.address, group.size) == expected[index],
                group.config.label .. ' full-table verification failed')
        end
    end)
    if ok then return end

    local restored = true
    for index = #attempted, 1, -1 do
        local item, edit = attempted[index], attempted[index].edit
        local current = api.read(item.group.address + edit.offset, #edit.before)
        local owned = current ~= nil and #current == #edit.before
        if owned then
            for byte = 1, #current do
                local value = current:byte(byte)
                if value ~= edit.before:byte(byte) and value ~= edit.after:byte(byte) then
                    owned = false
                    break
                end
            end
        end
        if owned and current ~= edit.before then
            local wrote = pcall(item.group.writer, item.group.address + edit.offset, edit.before)
            current = api.read(item.group.address + edit.offset, #edit.before)
            restored = (wrote and current == edit.before) and restored
        elseif not owned then
            restored = false
        end
    end
    error(tostring(reason) .. '; restored=' .. tostring(restored))
end

local function plans_for(api, module, config)
    local plans = {}
    for _, address in ipairs(locate(api, module, config)) do
        local plan, reason = make_plan(api, address, config)
        if plan then plans[#plans + 1] = plan
        elseif api.note then api.note(config.label .. ': ' .. tostring(reason)) end
    end
    return plans
end

function patch.apply(api, module)
    local ok, applied, reason = pcall(function()
        local exe, game = api.module(nil), api.module('game.dll')
        assert(exe ~= nil and game ~= nil, 'Game modules unavailable')
        assert(api.module_hash(exe) == GAME_BUILD_EXE, 'Unsupported executable. No edit applied.')
        assert(api.module_hash(game) == GAME_BUILD_DLL, 'Unsupported game module. No edit applied.')

        local weapon = plans_for(api, module, TABLES.weapon)
        local magazine = plans_for(api, module, TABLES.magazine)
        if #weapon == 0 or #magazine == 0 then return false, 'not-ready' end
        local pairs = {}
        local expected_distance = TABLES.weapon.file_offset - TABLES.magazine.file_offset
        for _, weapon_plan in ipairs(weapon) do
            for _, magazine_plan in ipairs(magazine) do
                if api.distance(weapon_plan.address, magazine_plan.address) == expected_distance then
                    pairs[#pairs + 1] = {weapon_plan, magazine_plan}
                end
            end
        end
        assert(#pairs == 1, 'Expected one matching R/40-K generated-data instance; found ' .. #pairs .. '. No edit applied.')
        commit(api, pairs[1])
        return true, 'Applied v0.8: R/40-K ergonomics 30 -> 45; 20 rounds per magazine; 5 starting / 5 refill / 5 maximum magazines. Stock magazine component retained. In-game behavior unverified.'
    end)
    if not ok then return false, tostring(applied) end
    return applied, reason
end

return patch
