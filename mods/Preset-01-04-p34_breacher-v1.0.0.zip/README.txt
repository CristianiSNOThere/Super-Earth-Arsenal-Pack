Preset 1 - P-34 Breacher

A standalone package for this entity's saved Preset 1 values. It applies only the settings listed below.

Supported build

- Helldivers 2 Steam build 25480438.
- Bingus Shared Loader v15 or newer.
- The package checks the supported executable/game module fingerprints and source-backed fields before writing.

Preset values

- Entity resource hash: `E91F569C2AD8AF01`.
- `mags_supply` = `2`.

How it works

- This package contains a fixed profile for this one entity; it does not open the F8 editor.
- It does not read or write the source editor's config or preset files.
- All fields for this entity are preflighted and applied as one transaction. A conflict or unsupported field refuses the complete entity profile and rolls back any partial writes.
- At launch the runtime allows 30 seconds for the other installed Arsenal modules to initialize, then waits up to two minutes for any detected Flag, SAI, AR-11, Sterilizer, or ARC-3 module to report Applied. If one fails, this profile writes nothing.
- If installed alongside the source editor, disable overlapping values from its active config before using this package. The package will refuse fields that another mod has already changed.

Install and test

Import this ZIP into Arsenal and enable its option. The user handles import and deployment. Restart the game after changing enabled mods, then confirm the loader log reports this profile as applied before gameplay testing.

This is a local package; it has not been published or deployed.
