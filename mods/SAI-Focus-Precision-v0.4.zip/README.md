# SAI - Focus Precision v0.4

- Normal bullet damage: 80 -> 90, with any lens.
- Durable bullet damage: 4 -> 21, the mean of the eight other primary SMGs.
- Focus Lens horizontal/vertical spread: 75 -> 0.5 MRAD (99.3% reduction).
- Other lenses, penetration, recoil, heat and fire rate retain their values.

This mod works on its own; no Flag or AR-11 package is required. If another enabled mod changes the shared data during SAI setup, this version retries that stale snapshot safely. Flag compatibility remains optional when both mods are enabled.

Close the game. Import this ZIP into Arsenal and enable its option. If using the flag mod, use Adjustable Damage v0.9 for compatibility and keep your chosen damage settings. Keep Bingus Shared Loader last. Purge, Deploy, restart the game, and wait aboard the ship for initialization. Equip the Focus Lens before testing accuracy.

Check %LOCALAPPDATA%/CowboyBingus/Helldivers2/Logs/SaiFocusMod.log for `status=Applied`. Missing or changed data makes the mod refuse the edit. Disable the mod, redeploy, and restart to restore stock values.

Requires Steam build 25480438. Other mods changing either complete table may cause validation to refuse the edit. The package does not edit Arsenal settings or deploy itself.

Durable damage inputs (stock bullet values):
- MP-98 Knight: 18
- SMG/FLAM-34 Stoker: 30
- StA-11 SMG: 18
- M7S SMG: 18
- SMG-32 Reprimand: 32
- SMG-72 Pummeler: 13
- SMG-37 Defender: 22
- SMG-203 Gallant: 17

168 / 8 = 21 durable damage. Stoker flamethrower damage is excluded.
