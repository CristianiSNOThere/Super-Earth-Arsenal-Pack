local patch={}
local function u32(s,o)
    if not s or o<0 or o+4>#s then return nil end
    local a,b,c,d=s:byte(o+1,o+4)
    return a+b*256+c*65536+d*16777216
end
local function pack(v)
    return string.char(v%256,math.floor(v/256)%256,math.floor(v/65536)%256,math.floor(v/16777216)%256)
end
local function replace(s,o,b) return s:sub(1,o)..b..s:sub(o+#b+1) end
local function unhex(s) return (s:gsub('..',function(h) return string.char(tonumber(h,16)) end)) end
local DAMAGE_SIGNATURE=unhex('310000005000000004000000030000000300000003000000000000000a0000000a0000000a000000000000000000000000000000000000000000000000000000000000000000000000000000')
local FOCUS_SIGNATURE=unhex('63bd3f91b5cb88a16dcd7c827321dd4d0000000000001644000000000000964200009642000000000000c0c01200000000000000120000000000000012000000000000001200000000000000120000000000000012000000000000001200000000000000')
local DELTA_HEADER=unhex('4f603e684c444c44010000004f603e68665505000100000000000000')
local DELTA_ARRAYS={ {28,108,1024},{44,16492,1122},{60,25468,1011},{76,37600,6040},{92,110080,239490} }

local function damage(api,address)
    local size=49424
    if not api.writable(address,size) then return nil,'damage data not writable' end
    local s=api.read(address,size)
    if not s or #s~=size or u32(s,0)~=2 then return nil,'damage layout mismatch' end
    for _,h in ipairs({{4,3943969754,32},{60,3769052400,49340}}) do
        if u32(s,h[1])~=0x444c444c or u32(s,h[1]+4)~=1 or u32(s,h[1]+8)~=h[2]
          or u32(s,h[1]+12)~=h[3] or u32(s,h[1]+16)~=1 or u32(s,h[1]+20)~=0 then return nil,'damage header mismatch' end
    end
    if u32(s,92)~=649 or u32(s,96)~=0 then return nil,'damage count mismatch' end
    local pointer=api.pointer(s,84)
    if not pointer or api.distance(pointer,address)~=100 then return nil,'damage pointer mismatch' end
    local normalized=s
    local peer=rawget(_G,'FlagDamagePrototypeV1')
    if peer and peer.active then
        local n,d=peer.status:match('Applied: flag damage 200 %-> (%d+); durable damage 100 %-> (%d+)%.')
        n,d=tonumber(n),tonumber(d)
        if not n or not d or u32(s,41980)~=n or u32(s,41984)~=d then return nil,'flag companion values mismatch' end
        normalized=replace(s,41980,pack(200)..pack(100))
    end
    if api.sha256(normalized:sub(101))~='7BDD751C1336E5BEA8023B5C12A6A8FC60E1EE0BF50132D6BAFDA9D44AD1F72A' then return nil,'damage rows checksum mismatch' end
    if s:sub(4205,4280)~=DAMAGE_SIGNATURE then return nil,'SAI record mismatch' end
    return {address=address,size=size,source=s,offset=4208,bytes=pack(90)..pack(21)}
end

local function focus(api,address)
    local size=349570
    if not api.data_access(address,size) then return nil,'attachment data permissions unsupported' end
    if api.read(address,28)~=DELTA_HEADER then return nil,'attachment header mismatch' end
    local s=api.read(address,size)
    if not s or #s~=size then return nil,'attachment read failed' end
    for _,a in ipairs(DELTA_ARRAYS) do
        local pointer=api.pointer(s,a[1])
        if not pointer or api.distance(pointer,address)~=a[2] or u32(s,a[1]+8)~=a[3] or u32(s,a[1]+12)~=0 then return nil,'attachment pointer/count mismatch' end
    end
    if api.sha256(s:sub(109))~='3A394B39EE2AEEBD916179E8199F11D5F135D56C0F074694CF4E051AF70CDB85' then return nil,'attachment checksum mismatch' end
    if s:sub(181582,181681)~=FOCUS_SIGNATURE then return nil,'complete Focus Lens payload mismatch' end
    -- IEEE 754 float 0.5, horizontal and vertical. All other lens fields stay stock.
    return {address=address,size=size,source=s,offset=181609,bytes=unhex('0000003f0000003f'),attachment=true}
end

local function find(api,module,validator,signature,offset,header,label)
    local plans,seen={},{}
    local addresses
    if label=='Focus Lens' then addresses=api.scan_private(signature,181581,true)
    else addresses=api.candidates(module,signature,offset,header) end
    for _,address in ipairs(addresses) do
        local key=api.identity(address)
        if not seen[key] then
            seen[key]=true
            local plan,reason=validator(api,address)
            if api.note then api.note(label..' address='..string.format('%.0f',key)..': '..(reason or 'validated')) end
            if plan then plans[#plans+1]=plan end
        end
    end
    assert(#plans==1,'Expected one supported '..label..' table; found '..#plans..'. No edit applied.')
    return plans[1]
end

function patch.apply(api,module)
    local ok,result=pcall(function()
        local plans={find(api,module,damage,DAMAGE_SIGNATURE,4204,nil,'damage'),
          find(api,module,focus,FOCUS_SIGNATURE,181581,nil,'Focus Lens')}
        -- Discovery can yield. Recheck both complete tables before committing.
        for _,p in ipairs(plans) do
            assert(api.read(p.address,p.size)==p.source,'Data changed before edit. No edit applied.')
        end
        local attempted={}
        local applied,reason=pcall(function()
            for _,p in ipairs(plans) do
                attempted[#attempted+1]=p
                local write=p.attachment and api.write_attachment or api.write
                assert(write(p.address+p.offset,p.bytes),'Write incomplete')
            end
            for _,p in ipairs(plans) do
                assert(api.read(p.address,p.size)==replace(p.source,p.offset,p.bytes),'Full table verification failed')
            end
        end)
        if not applied then
            local restored=true
            for i=#attempted,1,-1 do
                local p=attempted[i]
                local before=p.source:sub(p.offset+1,p.offset+#p.bytes)
                local current=api.read(p.address,p.size)
                local owned=current and replace(current,p.offset,before)==p.source
                if owned then
                    for j=1,#p.bytes do
                        local b=current:byte(p.offset+j)
                        if b~=before:byte(j) and b~=p.bytes:byte(j) then owned=false end
                    end
                end
                if owned then
                    local write=p.attachment and api.write_attachment or api.write
                    restored=(write(p.address+p.offset,before) and api.read(p.address,p.size)==p.source) and restored
                else restored=false end
            end
            error(tostring(reason)..'; restored='..tostring(restored))
        end
        return 'Applied: SAI normal damage 80 -> 90; durable damage 4 -> 21; Focus Lens spread 75 -> 0.5 MRAD on both axes.'
    end)
    return ok,tostring(result)
end
return patch
