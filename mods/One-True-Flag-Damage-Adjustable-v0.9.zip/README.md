# One True Flag - Adjustable Damage v0.9

Arsenal's Version 1 mod options support selectable variants rather than a
free-entry number field. This pack uses four digit selectors to set any
whole-number normal damage from 0 to 9999 inside Arsenal.

Default: 300 normal damage / 150 durable damage. The tested v0.6 discovery
and write method is retained; these new configuration controls have passed
offline tests but still need an in-game check.

## Install and choose damage

1. Close Helldivers 2. Replace the previous flag mod with this ZIP in Arsenal.
2. Enable the mod and Apply configurable flag damage.
3. Enable Thousands, Hundreds, Tens and Ones, then pick one sub-option in
   each. Their displayed contributions add together to give normal damage.
4. Choose Durable damage: Half of normal damage (default) or Equal to normal
   damage. Fractions are rounded down.
5. Keep Bingus Shared Loader last with default priority. Purge and Deploy.
6. Relaunch and wait aboard the ship for initialization. Allow two minutes.
   %LOCALAPPDATA%/CowboyBingus/Helldivers2/Logs/FlagDamagePrototype.log
   reports the actual applied normal and durable values.

Examples:

| Normal damage | Thousands | Hundreds | Tens | Ones |
| --- | --- | --- | --- | --- |
| 300 | 0 | 300 | 0 | 0 |
| 750 | 0 | 700 | 50 | 0 |
| 1250 | 1000 | 200 | 50 | 0 |
| 9999 | 9000 | 900 | 90 | 9 |

If a digit option is disabled it uses its default: Thousands 0, Hundreds
300, Tens 0, Ones 0. Disabling Durable damage uses half of normal. To set
zero damage, explicitly select Hundreds 0 as well as zeros elsewhere.
Enable Apply configurable flag damage for any of these settings to apply.
Changing selections requires Purge/Deploy and a game restart. There is no
live update while the game is running.

## Scope and compatibility

Armor penetration, force, stun and other fields are unchanged. Damage does
not bypass armor immunity. Requires Steam build 25480438 and Bingus Shared
Loader v17 or newer; the installed v18 is supported. Only one flag version
should be enabled. Compatible with SAI Focus Precision v0.1 (90/21). Another mod changing the same damage table may cause the
full-table validation to reject it; keep the M1000 AP4 mod disabled for testing.

The script validates module hashes, table layout and complete original row
hashes before changing only the two adjacent flag damage integers. Pointer
identity uses numeric addresses, retaining the v0.6 fix. The main script
waits for loading, so all selected setting modules can initialize regardless
of discovery order. Missing settings have explicit defaults; invalid values
are rejected. No configuration files or existing Arsenal settings are edited
by the addon.

Disable/remove the flag mod, redeploy and restart to restore original damage.
Changes apply only to the loaded game data for that game process.

References:
- Arsenal options: https://docs.rsnl.gg/mod-builder/options
- Arsenal manifest: https://docs.rsnl.gg/mod-builder/manifest
- https://github.com/CowboyBingus/BingusSharedLoader/releases/tag/v18
