local patch = {}
local SIZE, COUNT, STRIDE = 49424, 649, 76
local TABLE_SHA = '7BDD751C1336E5BEA8023B5C12A6A8FC60E1EE0BF50132D6BAFDA9D44AD1F72A'
local FLAG = '2d020000c800000064000000030000000000000000000000000000000a000000230000001e00000000000000270000000000a040000000000000000000000000000000000000000000000000'
local function u32(s, o)
    if not s or o < 0 or o + 4 > #s then return nil end
    local a,b,c,d = s:byte(o+1,o+4)
    return a+b*256+c*65536+d*16777216
end
local function set(s,o,b) return s:sub(1,o)..b..s:sub(o+#b+1) end
local function pack32(v)
    return string.char(v%256,math.floor(v/256)%256,math.floor(v/65536)%256,math.floor(v/16777216)%256)
end
function patch.damage_values(settings)
    settings=settings or {}
    assert(type(settings)=='table','Invalid damage settings')
    local normal=0
    for _,digit in ipairs({{'thousands',1000,0},{'hundreds',100,300},{'tens',10,0},{'ones',1,0}}) do
        local value=settings[digit[1]]
        if value==nil then value=digit[3] end
        assert(type(value)=='number' and value>=0 and value<=9*digit[2] and value%digit[2]==0,'Invalid '..digit[1]..' setting')
        normal=normal+value
    end
    local ratio=settings.durable_ratio or 50
    assert(ratio==50 or ratio==100,'Invalid durable damage ratio')
    return normal,math.floor(normal*ratio/100)
end
local SIGNATURE = FLAG:gsub('..',function(hex) return string.char(tonumber(hex,16)) end)

local function identify(api, address)
    if not api.writable(address, SIZE) then return nil,'not writable private data' end
    local s = api.read(address, SIZE)
    if not s or #s ~= SIZE then return nil,'full table read failed' end
    if u32(s,0) ~= 2 then return nil,'not a two-group table' end
    for _, h in ipairs({{4,3943969754,32},{60,3769052400,49340}}) do
        if u32(s,h[1]) ~= 0x444c444c or u32(s,h[1]+4) ~= 1
          or u32(s,h[1]+8) ~= h[2] or u32(s,h[1]+12) ~= h[3]
          or u32(s,h[1]+16) ~= 1 or u32(s,h[1]+20) ~= 0 then return nil,'group header mismatch at '..h[1] end
    end
    if u32(s,92) ~= COUNT or u32(s,96) ~= 0 then return nil,'row count mismatch' end
    local ptr = api.pointer(s,84)
    if not ptr or api.distance(ptr,address) ~= 100 then return nil,'relocated pointer mismatch: '..tostring(ptr and api.distance(ptr,address)) end
    -- Accept only the exact companion SAI v0.1 edit; hash every other byte.
    local normalized=s
    if u32(s,4208)==90 and u32(s,4212)==21 then
        normalized=set(s,4208,pack32(80)..pack32(4))
    end
    local hash=api.sha256(normalized:sub(101))
    if hash ~= TABLE_SHA then return nil,'rows hash mismatch: '..hash end
    local offset, seen = nil, {}
    for i=0,COUNT-1 do
        local o = 100+i*STRIDE
        local kind = u32(s,o)
        if not kind or seen[kind] then return nil,'duplicate or invalid row '..i end
        seen[kind] = true
        if kind == 557 then
            local hex = s:sub(o+1,o+STRIDE):gsub('.',function(c) return string.format('%02x',c:byte()) end)
            if hex ~= FLAG then return nil,'flag record mismatch: '..hex end
            offset = o+4
        end
    end
    if not offset then return nil,'flag row missing' end
    return {address=address, source=s, offset=offset}
end

function patch.apply(api, module)
    local ok, result = pcall(function()
        local normal,durable=patch.damage_values(rawget(_G,'FlagDamageOptionsV1'))
        local NEW_DAMAGE=pack32(normal)..pack32(durable)
        local candidates, seen = {}, {}
        for _,address in ipairs(api.candidates(module,SIGNATURE,41976)) do
            local identity = api.identity(address)
            if not seen[identity] then
                seen[identity] = true
                local plan,reason = identify(api,address)
                if api.note then api.note(string.format('address=%.0f',identity)..': '..(reason or 'fully validated table')) end
                if plan then candidates[#candidates+1] = plan end
            end
        end
        assert(#candidates == 1, 'Expected one supported damage table; found '..#candidates..'. No edit applied.')
        local p = candidates[1]
        assert(api.read(p.address,SIZE) == p.source, 'Damage data changed before edit. No edit applied.')
        local expected = set(p.source,p.offset,NEW_DAMAGE)
        local before = p.source:sub(p.offset+1,p.offset+8)
        local applied, reason = pcall(function()
            assert(api.write(p.address+p.offset,NEW_DAMAGE), 'Damage write was incomplete')
            assert(api.read(p.address,SIZE) == expected, 'Full damage-table verification failed')
        end)
        if not applied then
            local now = api.read(p.address,SIZE)
            local recoverable = now and #now == SIZE and set(now,p.offset,before) == p.source
            if recoverable then
                for i=1,8 do
                    local b=now:byte(p.offset+i)
                    if b ~= before:byte(i) and b ~= NEW_DAMAGE:byte(i) then recoverable=false end
                end
            end
            local recovered = recoverable and api.write(p.address+p.offset,before)
              and api.read(p.address,SIZE) == p.source
            error(tostring(reason)..'; restored='..tostring(not not recovered))
        end
        return 'Applied: flag damage 200 -> '..normal..'; durable damage 100 -> '..durable..'.'
    end)
    return ok, tostring(result)
end
return patch
