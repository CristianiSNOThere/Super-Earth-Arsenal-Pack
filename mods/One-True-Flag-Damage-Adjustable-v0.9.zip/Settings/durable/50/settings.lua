-- HD2-Addon: mods/codex/flag_settings/durable
local settings=rawget(_G,'FlagDamageOptionsV1') or {}
_G.FlagDamageOptionsV1=settings
settings.durable_ratio=50
