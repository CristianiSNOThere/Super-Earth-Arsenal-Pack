-- HD2-Addon: mods/codex/flag_settings/ones
local settings=rawget(_G,'FlagDamageOptionsV1') or {}
_G.FlagDamageOptionsV1=settings
settings.ones=9
