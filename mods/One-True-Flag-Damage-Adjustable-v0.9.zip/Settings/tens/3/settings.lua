-- HD2-Addon: mods/codex/flag_settings/tens
local settings=rawget(_G,'FlagDamageOptionsV1') or {}
_G.FlagDamageOptionsV1=settings
settings.tens=30
