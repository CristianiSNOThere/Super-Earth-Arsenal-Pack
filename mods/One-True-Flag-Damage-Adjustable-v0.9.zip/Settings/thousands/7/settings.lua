-- HD2-Addon: mods/codex/flag_settings/thousands
local settings=rawget(_G,'FlagDamageOptionsV1') or {}
_G.FlagDamageOptionsV1=settings
settings.thousands=7000
