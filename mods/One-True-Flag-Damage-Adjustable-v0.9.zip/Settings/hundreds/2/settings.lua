-- HD2-Addon: mods/codex/flag_settings/hundreds
local settings=rawget(_G,'FlagDamageOptionsV1') or {}
_G.FlagDamageOptionsV1=settings
settings.hundreds=200
