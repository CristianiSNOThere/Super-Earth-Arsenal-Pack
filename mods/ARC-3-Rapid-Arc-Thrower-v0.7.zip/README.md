# ARC-3 Rapid Arc Thrower v0.7

This separate Arsenal package makes the ARC-3 fire closely spaced arc pulses. Enable **Arc Thrower Revamped** in CowboyBingus's Vanilla Plus Megapack for hold-to-fire. The Bingus package itself is untouched.

## Gameplay changes

| ARC-3 value | Stock | v0.7 |
|---|---:|---:|
| Minimum / full / overcharge time | 1.0 / 1.1 / 1.2 s | 0.20 / 0.22 / 0.24 s |
| Normal / durable damage per pulse | 250 / 100 | 163 / 65 |
| Stun Medium buildup per pulse | 8 | 0.8 |
| Demolition / stagger / push per pulse | 20 / 35 / 10 | 4 / 7 / 2 |
| Camera climb, horizontal / vertical | 1.0 / 1.0 | 0.4 / 0.4 |
| Primary arc reach | 55 m | 40 m |

The supported game data gives the tougher Charger head 1,600 zone health, 100% durable damage weighting, armor 4, and death of the entity when the head dies. ARC-3 armor penetration 7 is unchanged. On uninterrupted head hits, `ceil(1600 / 65) = 25` pulses. At an assumed 0.20-second firing interval, that is approximately five seconds from starting to charge. Actual timing, hit registration, and kill behavior need in-game confirmation. The earlier 15% stock DPS target is superseded by this Behemoth head-kill target. The higher pulse damage will also affect other enemies.

The two camera climb multipliers are reduced by 60%. This should soften visible kick. v0.7 shortens the ARC-3's primary reach to 40 m and halves Stun Medium buildup compared with v0.5. That reduces crowd control without changing damage or stagger. Camera shake, weapon drift, arc visuals, chaining, armor penetration, and charge damage multipliers remain unchanged. The effective maximum distance and stun feel need in-game checks.

## Install and test

1. Finish the current mission and close the game. Replace or disable earlier Rapid Arc Thrower versions in Arsenal, then import this **v0.7** ZIP and enable its single option. Do not leave multiple versions active. Keep Bingus Shared Loader v18 or later enabled.
2. Enable **Arc Thrower Revamped** in the Vanilla Plus Megapack for hold-to-fire. Purge and Deploy in Arsenal, then launch the game.
3. Allow up to two minutes for initialization. Check `%LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\RapidArcThrower.log` for `RapidArcThrower v0.7` and `Applied`.
4. In a mission, check that the primary arc reaches targets inside 40 m but stops reaching beyond it. Then hold fire on a Charger Behemoth's head from within range. Count pulses and elapsed time; record misses and interrupted arcs separately. Assess camera climb, frame rate, and stun.

The ZIP does not import, deploy, or change Arsenal settings. Disable it, redeploy, and restart the game to restore stock process data.

## Compatibility and limits

Supported only on Steam build `25480438` with the exact executable and `game.dll` fingerprints in the validation report. The mod verifies unique ARC-3 damage, range, charge, and recoil records, exact source values, and write readback; it rolls back recognizable partial writes. It accepts one confirmed companion change: Bingus Arc Thrower Revamped sets the ARC-3 auto-fire flag from 0 to 1, which this mod preserves. Conflicting target-record edits cause refusal. Its bounded allocation lookup avoids the bulk memory scan that caused the v0.2 frame-rate drop. The range row is found through game-module pointers, without a broad private-memory scan. v0.6 did not apply because its range-table check mistook the live row pointer for a row count; v0.7 uses the pointer and count offsets observed in the user's running game. Successful application still needs a game-run confirmation.

Charge audio remains unchanged. A safe, scoped charge-cue volume reduction has not been validated. This package has offline validation; the user performs deployment and in-game confirmation before any public release.
