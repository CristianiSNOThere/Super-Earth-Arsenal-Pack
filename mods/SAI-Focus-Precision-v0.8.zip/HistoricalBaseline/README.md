Offline test candidate. User handles deployment/gameplay; no publication.
ARC-3 Stun Medium buildup0.8 ->1.2; other ARC settings retained.
TX-41 Acid Storm duration6 ->15seconds; shared Acid Storm status also affected.
SAI/Sterilizer exact ARC0.11 compatibility guards updated; other tuning retained.
Offline shipped LuaJIT transactions/rollback, peer versions/values/checksum,
Acid field guard/scope and ZIP/resource checks passed. Startup/gameplay NOTRUN.
Use complete modpack OR individual Arc+Sterilizer+SAI candidates, never both.
Do not deploy while testing Punisher. Replace existing versions and restart when
ready. Check fresh startup logs before testing weapons. No settings changes.

Historical baseline documentation follows; values above supersede it.
# SAI Focus Precision

## Current gameplay changes

Sets LAS-12 SAI normal damage to 90 and durable damage to 21 with any lens. Sets Focus Lens horizontal and vertical spread to 0.5 MRAD.

## Controls and compatibility

Equip the Focus Lens for the precision spread. Compatible with the supported shared damage-table edits from One True Flag, AR-11 Arbitrator, and ARC-3 Rapid Arc Thrower v0.9 and v0.10.

## Install

Import the ZIP into Arsenal and enable its option. Keep Bingus Shared Loader at its documented priority, Purge and Deploy, and restart Helldivers 2. Choose the individual packages or the modpack to avoid duplicate addon resources.

Requires Helldivers 2 Steam build 25480438 and Bingus Shared Loader v17 or newer.

## Initialization

Startup discovery limits work per frame and searches game data libraries. Weapon and sentry tuning waits for installed companion mods to finish initializing.
