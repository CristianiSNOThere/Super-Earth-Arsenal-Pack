# ARC-3 Rapid Arc Thrower v0.9

This separate Arsenal package makes the ARC-3 fire closely spaced arc pulses. Enable **Arc Thrower Revamped** in CowboyBingus's Vanilla Plus Megapack for hold-to-fire. The Bingus package itself is untouched.

## Gameplay changes

| ARC-3 value | Stock | v0.9 |
|---|---:|---:|
| Minimum / full / overcharge time | 1.0 / 1.1 / 1.2 s | 0.20 / 0.22 / 0.24 s |
| Normal / durable damage per pulse | 250 / 100 | 163 / 65 |
| Stun Medium buildup per pulse | 8 | 0.8 |
| Demolition / force strength / impulse per pulse | 20 / 35 / 10 | 4 / 25 / 2 |
| Camera climb, horizontal / vertical | 1.0 / 1.0 | 0.4 / 0.4 |
| Primary arc reach | 55 m | 40 m |

The supported game data gives the tougher Charger head 1,600 zone health, 100% durable damage weighting, armor 4, and death of the entity when the head dies. ARC-3 armor penetration 7 is unchanged. On uninterrupted head hits, `ceil(1600 / 65) = 25` pulses. At an assumed 0.20-second firing interval, that is approximately five seconds from starting to charge. Actual timing, hit registration, and kill behavior need in-game confirmation. The earlier 15% stock DPS target is superseded by this Behemoth head-kill target. The higher pulse damage will also affect other enemies.

The two camera climb multipliers are reduced by 60%. This softens visible kick. v0.9 keeps v0.8's force strength at 25 and reduces only its impulse from 5 to 2 for gentler pushback. Stun Medium buildup remains 0.8. Force strength and impulse are still below stock ARC-3's 35/10. The v0.9 launch log confirmed these values applied, and the user confirmed the final balance feels right in-game. Camera shake, weapon drift, arc visuals, chaining, armor penetration, and charge damage multipliers remain unchanged.

## Install and test

1. Finish the current mission and close the game. Replace or disable earlier Rapid Arc Thrower versions in Arsenal, then import this **v0.9 ZIP** and enable its single option. Do not leave multiple versions active. Keep Bingus Shared Loader v18 or later enabled.
2. Enable **Arc Thrower Revamped** in the Vanilla Plus Megapack for hold-to-fire. Purge and Deploy in Arsenal, then launch the game.
3. Allow up to two minutes for initialization. Check `%LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\RapidArcThrower.log` for `RapidArcThrower v0.9` and `Applied`.
4. In a mission, test Alpha Commanders at typical combat range. Note whether a pulse pushes or staggers them, and whether repeated pulses prevent them from acting at all. Recheck the Charger Behemoth feel within 40 m; damage and Stun Medium buildup are unchanged from v0.7.

The ZIP does not import, deploy, or change Arsenal settings. Disable it, redeploy, and restart the game to restore stock process data.

## Compatibility and limits

Supported only on Steam build `25480438` with the exact executable and `game.dll` fingerprints in the validation report. The mod verifies unique ARC-3 damage, range, charge, and recoil records, exact source values, and write readback; it rolls back recognizable partial writes. It accepts one confirmed companion change: Bingus Arc Thrower Revamped sets the ARC-3 auto-fire flag from 0 to 1, which this mod preserves. Conflicting target-record edits cause refusal. Its bounded allocation lookup avoids the bulk memory scan that caused the v0.2 frame-rate drop. The range row is found through game-module pointers, without a broad private-memory scan. v0.9 applied successfully in-game and the user confirmed its feel.

Charge audio remains unchanged. A safe, scoped charge-cue volume reduction has not been validated. The v0.7 release remains available for anyone who prefers its lighter hit reaction.
