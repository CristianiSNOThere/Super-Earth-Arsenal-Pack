# R/40-K Hot-Shot v0.8 — Magazine Tuning (Local Prototype)

This local test prototype keeps the R/40-K's stock finite-magazine behavior. It does not convert the rifle to heat or heatsinks.

## Changes

- Magazine capacity: 12 → 20 rounds.
- Starting magazines: 5 (unchanged).
- Magazines from resupply: 7 → 5.
- Maximum magazines: 7 → 5.
- Ergonomics: 30 → 45.
- Damage, fire mode, component declaration, reload behavior, and all heat/network settings remain stock.

The runtime addon follows the table-finding and guarded in-memory edit pattern used by the working AR-11 and SAI mods. It verifies the supported game build, R/40-K resource-to-record mappings, table layout, target baseline values, and that the weapon and magazine tables belong to the same generated-data instance. It confirms the starting magazine count is already five, then writes only magazine capacity, refill count, maximum count, and ergonomics. It verifies the complete tables and rolls back its own writes if verification fails.

## Local test package

This prototype is not released or deployed. If you choose to test it, replace the older Hot-Shot prototype in Arsenal; enable only this Hot-Shot option. Keep all other mod selections and loadouts unchanged, and keep Bingus Shared Loader last. After launching, check `%LOCALAPPDATA%/CowboyBingus/Helldivers2/Logs/R40KMagazineTune.log` for `Applied v0.8`.

In a mission, confirm the HUD and reload behavior show 20 rounds per magazine and a five-magazine supply, and that the weapon has 45 ergonomics. The behavior is not confirmed until you verify it in game. Keep Hot-Shot unreleased until you confirm those values.

Supported target: Steam build 25480438 / game 1.007.101. The add-on changes process memory only; it does not edit Arsenal selections, saved loadouts, or game files.
