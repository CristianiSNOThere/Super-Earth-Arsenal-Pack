# SAI - Focus Precision v0.5

- Normal bullet damage: 80 -> 90, with any lens.
- Durable bullet damage: 4 -> 21, the mean of the eight other primary SMGs.
- Focus Lens horizontal/vertical spread: 75 -> 0.5 MRAD (99.3% reduction).
- Other lenses, penetration, recoil, heat and fire rate retain their values.

This mod works on its own. It also supports the exact shared damage-table
edits from Flag v0.9, AR-11 v0.2, and ARC-3 v0.9. Other or unsupported edits
to that table cause SAI to refuse the change.

Close the game. Import this ZIP into Arsenal and enable its option.
Keep Bingus Shared Loader last. Purge, Deploy, restart the game, and wait
aboard the ship for initialization. Equip the Focus Lens to use its precision tuning.

Check %LOCALAPPDATA%/CowboyBingus/Helldivers2/Logs/SaiFocusMod.log for
the applied message. Missing or changed data causes it to refuse the edit.

Disable the mod, redeploy and restart to restore stock values.
Requires Steam build 25480438 and Bingus Shared Loader v17 or newer. This
package does not edit your Arsenal settings or deploy itself.

Durable damage inputs (stock bullet values):
- MP-98 Knight: 18
- SMG/FLAM-34 Stoker: 30
- StA-11 SMG: 18
- M7S SMG: 18
- SMG-32 Reprimand: 32
- SMG-72 Pummeler: 13
- SMG-37 Defender: 22
- SMG-203 Gallant: 17

168 / 8 = 21 durable damage. Stoker flamethrower damage is excluded.
