local patch = {}

local DAMAGE_SIZE, DAMAGE_COUNT, DAMAGE_STRIDE = 49424, 649, 76
local DAMAGE_SIGNATURE_HEX = '850000004600000014000000020000000200000002000000000000000a0000000f0000000c000000000000000000000000000000000000000000000000000000000000000000000000000000'
local STOCK_AR11_DAMAGE = '850000004600000014000000020000000200000002000000000000000a0000000f0000000c000000000000000000000000000000000000000000000000000000000000000000000000000000'
local STOCK_UNDERBARREL_DAMAGE = 'a1000000320000000c000000030000000300000003000000000000000a0000001400000014000000000000000000000000000000000000000000000000000000000000000000000000000000'
local ENTITY_CONFIGS = {
    {
        label='AR-11 ergonomics',
        signature='b1dbe4884c444c4401000000b1dbe488000f07000100000000000000',
        wrapper=0x88e4dbb1, group_size=462592,
        map_count=730, data_offset=11680, record_count=366, stride=1232,
        resource_lo=0x4892b6b2, resource_hi=0xa8a91eb5, expected_index=280,
        field_offset=356,
        before='0000f041', after='00002442',
    },
    {
        label='AR-11 magazine capacity',
        signature='a3888dfb4c444c4401000000a3888dfb20cb00000100000000000000',
        wrapper=0xfb8d88a3, group_size=52000,
        map_count=540, data_offset=8640, record_count=271, stride=160,
        resource_lo=0x4892b6b2, resource_hi=0xa8a91eb5, expected_index=211,
        field_offset=136,
        before='2d000000', after='41000000',
    },
    {
        label='AR-11 underbarrel spare ammo',
        signature='721008664c444c440100000072100866f01000000100000000000000',
        wrapper=0x66081072, group_size=4336,
        map_count=50, data_offset=800, record_count=26, stride=136,
        resource_lo=0xf99b5335, resource_hi=0xb9c209b4, expected_index=14,
        field_offset=80,
        before='14000000', after='1e000000',
        guard_span='0000804000000000',
        guard_offset=72,
        extra_changes={
            {field_offset=88,before='14000000',after='1e000000'},
        },
    },
}

local function unhex(s)
    return (s:gsub('..', function(h) return string.char(tonumber(h, 16)) end))
end
local function u32(s, o)
    if not s or o < 0 or o + 4 > #s then return nil end
    local a,b,c,d = s:byte(o+1,o+4)
    return a+b*256+c*65536+d*16777216
end
local function set(s, o, b)
    return s:sub(1,o)..b..s:sub(o+#b+1)
end
local function pack32(v)
    return string.char(v%256,math.floor(v/256)%256,math.floor(v/65536)%256,math.floor(v/16777216)%256)
end

local function damage_plan(api, module)
    local addresses = api.candidates(module, unhex(DAMAGE_SIGNATURE_HEX), 10588, nil)
    if #addresses == 0 then return nil, 'not-ready' end
    local plans, seen = {}, {}
    for _, address in ipairs(addresses) do
        local identity = api.identity(address)
        if not seen[identity] then
            seen[identity] = true
            if api.writable(address, DAMAGE_SIZE) then
                local s = api.read(address, DAMAGE_SIZE)
                if s and #s == DAMAGE_SIZE and u32(s,0) == 2
                    and u32(s,4) == 0x444c444c and u32(s,8) == 1
                    and u32(s,12) == 3943969754 and u32(s,16) == 32
                    and u32(s,20) == 1 and u32(s,24) == 0
                    and u32(s,60) == 0x444c444c and u32(s,64) == 1
                    and u32(s,68) == 3769052400 and u32(s,72) == 49340
                    and u32(s,76) == 1 and u32(s,80) == 0
                    and u32(s,92) == DAMAGE_COUNT and u32(s,96) == 0 then
                    local pointer = api.pointer(s,84)
                    if pointer and api.distance(pointer,address) == 100 then
                        local ids, positions = {}, {}
                        local unique = true
                        for i=0,DAMAGE_COUNT-1 do
                            local o=100+i*DAMAGE_STRIDE
                            local kind=u32(s,o)
                            if not kind or ids[kind] then unique=false;break end
                            ids[kind]=true
                            if kind==133 or kind==161 then positions[kind]=o end
                        end
                        if unique and positions[133]==10588 and positions[161]==12640
                            and s:sub(10589,10664)==unhex(STOCK_AR11_DAMAGE)
                            and s:sub(12641,12716)==unhex(STOCK_UNDERBARREL_DAMAGE) then
                            plans[#plans+1]={
                                label='AR-11 damage settings',
                                address=address,size=DAMAGE_SIZE,source=s,writer=api.write,
                                changes={
                                    {offset=positions[133]+4,before=pack32(70),after=pack32(80)},
                                    {offset=positions[161]+32,before=pack32(20),after=pack32(25)},
                                },
                            }
                        end
                    end
                end
            end
        end
    end
    if #plans ~= 1 then
        if #plans == 0 then return nil, 'damage-validation' end
        error('Expected one AR-11 damage table; found '..#plans..'. No edit applied.')
    end
    return plans[1]
end

local function entity_plan(api, address, config)
    local header=unhex(config.signature)
    local total=28+config.group_size
    if not api.data_access(address,total) then return nil,'component memory permissions unsupported' end
    local s=api.read(address,total)
    if not s or #s~=total then return nil,'component table read failed' end
    if s:sub(1,28)~=header or u32(s,0)~=config.wrapper
        or s:sub(5,8)~='LDLD' or u32(s,8)~=1
        or u32(s,12)~=config.wrapper or u32(s,16)~=config.group_size
        or u32(s,20)~=1 or u32(s,24)~=0 then return nil,'component header mismatch' end
    if config.data_offset~=config.map_count*16
        or config.group_size~=config.data_offset+config.record_count*config.stride then
        return nil,'component layout constants are inconsistent'
    end
    local found,index=0,nil
    for i=0,config.map_count-1 do
        local o=28+i*16
        local lo,hi=u32(s,o),u32(s,o+4)
        if lo==nil or hi==nil then return nil,'component map truncated' end
        if lo==config.resource_lo and hi==config.resource_hi then
            found=found+1
            index=u32(s,o+8)
        end
    end
    if found~=1 or index~=config.expected_index then return nil,'AR-11 resource mapping mismatch' end
    local record=28+config.data_offset+index*config.stride
    local function checked_change(member_offset,before_hex,after_hex)
        local field=record+member_offset
        local before,after=unhex(before_hex),unhex(after_hex)
        if field<28 or field+#before>total then return nil,'AR-11 field lies outside component table' end
        if #before~=#after or s:sub(field+1,field+#before)~=before then return nil,'AR-11 stock value mismatch' end
        return {offset=field,before=before,after=after}
    end
    local changes={}
    local main_change,change_reason=checked_change(config.field_offset,config.before,config.after)
    if not main_change then return nil,change_reason end
    changes[#changes+1]=main_change
    for _,extra in ipairs(config.extra_changes or {}) do
        local change,reason=checked_change(extra.field_offset,extra.before,extra.after)
        if not change then return nil,reason end
        changes[#changes+1]=change
    end
    if config.guard_span then
        local guard=record+config.guard_offset
        local span=unhex(config.guard_span)
        if guard<28 or guard+#span>total or s:sub(guard+1,guard+#span)~=span then
            return nil,'AR-11 magazine-capacity layout mismatch'
        end
    end
    return {
        label=config.label,address=address,size=total,source=s,writer=api.private_write,
        changes=changes,
    }
end

local function entity_plans(api,module)
    local items={}
    for i,config in ipairs(ENTITY_CONFIGS) do
        local header=unhex(config.signature)
        items[i]={signature=header,row_offset=0,key=i}
    end
    local addresses,seen={},{}
    -- Follow module-owned references when available, then scan private read-only
    -- and writable memory once to find relocated copies.
    for i,config in ipairs(ENTITY_CONFIGS) do
        local header=unhex(config.signature):sub(1,16)
        for _,address in ipairs(api.candidates(module,nil,0,header)) do
            local key=api.identity(address)
            if not seen[i..':'..key] then
                seen[i..':'..key]=true
                addresses[i]=addresses[i] or {}
                addresses[i][#addresses[i]+1]=address
            end
        end
    end
    local private=api.scan_private_many(items,true)
    for i,list in ipairs(private) do
        for _,address in ipairs(list) do
            local key=api.identity(address)
            if not seen[i..':'..key] then
                seen[i..':'..key]=true
                addresses[i]=addresses[i] or {}
                addresses[i][#addresses[i]+1]=address
            end
        end
    end
    local plans={}
    for i,config in ipairs(ENTITY_CONFIGS) do
        local valid={}
        for _,address in ipairs(addresses[i] or {}) do
            local plan=entity_plan(api,address,config)
            if plan then valid[#valid+1]=plan end
        end
        if #valid==0 then return nil,'not-ready' end
        if #valid~=1 then error('Expected one supported '..config.label..' table; found '..#valid..'. No edit applied.') end
        plans[#plans+1]=valid[1]
    end
    return plans
end

local function expected_after(plan)
    local result=plan.source
    for _,change in ipairs(plan.changes) do result=set(result,change.offset,change.after) end
    return result
end

local function apply_transaction(api, plans)
    for _,plan in ipairs(plans) do
        assert(api.read(plan.address,plan.size)==plan.source,plan.label..' changed before commit. No edit applied.')
        for _,change in ipairs(plan.changes) do
            assert(api.read(plan.address+change.offset,#change.before)==change.before,
                plan.label..' target changed before commit. No edit applied.')
        end
    end
    local attempted={}
    local ok,reason=pcall(function()
        for _,plan in ipairs(plans) do
            for _,change in ipairs(plan.changes) do
                attempted[#attempted+1]={plan=plan,change=change}
                assert(plan.writer(plan.address+change.offset,change.after),plan.label..' write was incomplete')
            end
        end
        for _,plan in ipairs(plans) do
            assert(api.read(plan.address,plan.size)==expected_after(plan),
                plan.label..' full-table verification failed')
        end
    end)
    if not ok then
        local restored=true
        for i=#attempted,1,-1 do
            local item=attempted[i]
            local current=api.read(item.plan.address+item.change.offset,#item.change.after)
            if current==item.change.after then
                local ok_write=item.plan.writer(item.plan.address+item.change.offset,item.change.before)
                if not ok_write then restored=false end
            elseif current~=item.change.before then
                restored=false
            end
        end
        for _,plan in ipairs(plans) do
            if api.read(plan.address,plan.size)~=plan.source then restored=false end
        end
        error(tostring(reason)..'; restored='..tostring(restored))
    end
end

function patch.apply(api,module)
    local ok,result=pcall(function()
        local damage,reason=damage_plan(api,module)
        if not damage then
            if reason=='not-ready' then error('AR11_DATA_NOT_READY',0) end
            error('AR-11 damage table validation failed. No edit applied.')
        end
        local entities,entity_reason=entity_plans(api,module)
        if not entities then
            if entity_reason=='not-ready' then error('AR11_DATA_NOT_READY',0) end
            error('AR-11 component table validation failed. No edit applied.')
        end
        local plans={damage}
        for _,plan in ipairs(entities) do plans[#plans+1]=plan end
        apply_transaction(api,plans)
        return 'Applied: AR-11 rifle damage 70 -> 80; rifle magazine 45 -> 65; underbarrel magazine remains 4 and reserve ammo 20 -> 30; stagger 20 -> 25 with push force 20 unchanged; ergonomics 29 -> 40 with the default optic.'
    end)
    if not ok and tostring(result)=='AR11_DATA_NOT_READY' then return false,'AR11_DATA_NOT_READY' end
    return ok,tostring(result)
end

return patch
