Offline test candidate. User handles deployment/gameplay; no publication.
ARC-3 Stun Medium buildup0.8 ->1.2; other ARC settings retained.
TX-41 Acid Storm duration6 ->15seconds; shared Acid Storm status also affected.
SAI/Sterilizer exact ARC0.11 compatibility guards updated; other tuning retained.
Offline shipped LuaJIT transactions/rollback, peer versions/values/checksum,
Acid field guard/scope and ZIP/resource checks passed. Startup/gameplay NOTRUN.
Use complete modpack OR individual Arc+Sterilizer+SAI candidates, never both.
Do not deploy while testing Punisher. Replace existing versions and restart when
ready. Check fresh startup logs before testing weapons. No settings changes.

Historical baseline documentation follows; values above supersede it.
# TX-41 Sterilizer

## Current gameplay changes

Applies the Acid Storm armor-reduction status with spray hits for 6 seconds. Sets Gas MKII damage to 45 DPS, magazine capacity to 175, and Gas MKII and Gas Confusion buildup per hit to 0.75. Sets the Helldiver incoming Gas multiplier to 0.7333.

## Controls and compatibility

Acid Storm temporarily reduces armor effectiveness. Gas MKII is shared with AX/TX-13 Guard Dog Dog Breath, which also deals 45 DPS. The Helldiver multiplier reduces incoming damage from all Gas sources, including grenades and hazards. The shared Acid Storm duration also affects weather status after the storm ends. Compatible with ARC-3 Rapid Arc Thrower v0.9 and v0.10.

## Install

Import the ZIP into Arsenal and enable its option. Keep Bingus Shared Loader at its documented priority, Purge and Deploy, and restart Helldivers 2. Choose the individual packages or the modpack to avoid duplicate addon resources.

Requires Helldivers 2 Steam build 25480438 and Bingus Shared Loader v18 or newer.

## Initialization

Startup discovery limits work per frame and searches game data libraries. Weapon and sentry tuning waits for installed companion mods to finish initializing.
