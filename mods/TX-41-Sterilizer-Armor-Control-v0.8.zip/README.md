# TX-41 Sterilizer - Armor Control v0.8

## Compatibility update

- Supports ARC-3 Rapid Arc Thrower v0.9 when both mods initialize successfully.
- ARC-3 and Sterilizer edit different records in the same damage table. This version recognizes ARC-3's exact v0.9 values while retaining the full-table checksum; unrelated or unsupported changes still cause the Sterilizer patch to refuse.
- The Sterilizer waits for an installed ARC-3 module to finish initialization before validating the shared table.

## Changes

- Adds the game's Acid Storm armor-reduction status to the Sterilizer spray.
- Acid Storm status duration: 1 -> 6 seconds (up from v0.4's 3 seconds).
- Gas MKII damage: 25 -> 45 damage per second (+50% over v0.5's 30 DPS; +36.4% over v0.6's 33 DPS).
- Helldiver incoming Gas multiplier: 1.3 -> 0.7333. This keeps the Gas MKII damage received by Helldivers near 33 per second as its damage rises to 45.
- Sterilizer magazine capacity: 125 -> 175 rounds (+40% over stock; +16.7% over v0.4).
- Gas MKII and Gas Confusion buildup per spray hit: 0.5 -> 0.75.
- Starting magazines, reserve magazines, reload behavior, penetration, and direct-hit damage are unchanged.

The player Gas multiplier is part of the Helldiver health record, so reducing it to 0.7333 lowers incoming damage from all Gas-element sources for Helldivers, including gas grenades, Dog Breath, and gas hazards; it does not reduce Fire damage. The Sterilizer's Gas MKII damage rises from 33 to 45 DPS, while the scaled player damage from that entry remains near 33 DPS. The Gas MKII damage record is shared with the AX/TX-13 Guard Dog Dog Breath, which will also deal 45 DPS while this package is active. Because the incoming multiplier is global, gas grenades and other Gas sources will hurt Helldivers about 43.6% less than with the stock 1.3 multiplier.

The Acid Storm duration is a shared game setting, so Acid Storm weather also keeps its armor-reduction status for up to 6 seconds after the weather effect stops.

The Acid Storm status temporarily lowers armor effectiveness; it does not permanently destroy armor plates. Its normal armor interaction can let follow-up weapons damage targets that were previously too armored for them.

## Install

1. Close Helldivers 2 and import this ZIP into Arsenal.
2. Enable **Sterilizer armor control and tuning**. Keep Bingus Shared Loader last with its default priority.
3. Purge, Deploy, launch the game, and wait up to two minutes aboard the ship for initialization.
4. Test the Sterilizer on a Charger leg, then follow with a light-penetration rifle to confirm whether the leg takes damage during the debuff.

The package does not deploy itself or change your Arsenal selections. Disable/remove it, redeploy, and restart to restore the stock process data.

## Compatibility and limits

Requires Steam build 25480438 and Bingus Shared Loader v18 or newer. It optionally recognizes Flag v0.9 (300/150), SAI v0.4 (90/21), AR-11 v0.2 (80 rifle damage / 25 stagger), and ARC-3 v0.9 (163/65 damage, 0.8 buildup, force values 4/25/2) edits when those mods are installed and initialize successfully. None are required dependencies. Other mods that change the same full damage table cause this package to refuse the edit. It changes only loaded process memory.

Cloud linger is not changed: the supported Sterilizer spray component exposes state effects, audio, and wind settings, but no per-weapon gas-cloud lifetime field. A separate slow status is not added because the game's existing gas effect already slows afflicted targets and the generic slow status has no large-target-only setting in the exposed weapon data.

This package has offline data/layout validation only and needs an in-game check. The script verifies the game module fingerprints, full damage table, exact Sterilizer magazine record, Acid Storm status record, Helldiver health record, companion values, and each write. It refuses unsupported layouts and restores recognizable partial writes.
