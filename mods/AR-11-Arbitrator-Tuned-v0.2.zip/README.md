# AR-11 Arbitrator - Tuned v0.2

- Rifle bullet damage: 70 -> 80. Durable damage and penetration stay unchanged.
- Rifle magazine: 45 -> 65 rounds.
- Underbarrel shotgun magazine remains 4 shells; starting and maximum spare ammo: 20 -> 30. The refill amount remains 20.
- Underbarrel stagger force: 20 -> 25. Push force stays at 20.
- Ergonomics: base 30 -> 41, giving 40 with the default optic's -1 modifier. Other optic modifiers remain in effect.

This is a standalone mod. It does not require the Flag Damage or SAI Focus packages. It validates the AR-11's own source values and refuses edits when those values do not match the supported game data. Concurrent changes to its target data trigger a safe retry; incompatible changes are refused.

## Install

1. Close Helldivers 2 and import this ZIP in Arsenal.
2. Enable the AR-11 upgrade option. Keep Bingus Shared Loader last at default priority.
3. Purge, Deploy, restart the game, and wait aboard the ship for initialization.
4. Check `AR11ArbitratorMod.log` in the Helldivers 2 log folder for `status=Applied`.

Requires Steam build 25480438 and Bingus Shared Loader v17 or newer. The package does not alter Arsenal settings, saved loadouts, or other installed mods.

Changes are process-local. Disable this package, Purge and Deploy, then restart to restore stock values.
